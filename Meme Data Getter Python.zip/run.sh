scrapy crawl -L INFO popular-memes &&
scrapy crawl -L INFO templates &&
scrapy crawl -L INFO memes &&
python statistics.py
